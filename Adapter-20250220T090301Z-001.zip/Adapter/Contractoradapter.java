package com.example.constra_sol.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.constra_sol.Modelclassall.Contructormodel;
import com.example.constra_sol.R;

import java.util.List;

public class Contractoradapter extends RecyclerView.Adapter<Contractoradapter.Myviewholder> {

    private Context mContext ;
    private List<Contructormodel> mData ;


    public Contractoradapter(Context mContext,List<Contructormodel>mData){


        this.mContext=mContext;
        this.mData=mData;

    }


    @NonNull
    @Override
    public Myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view;
        LayoutInflater minflater=LayoutInflater.from(mContext);
        view=minflater.inflate(R.layout.contructorlayout,parent,false);
return new Myviewholder(view);





    }

    @Override
    public void onBindViewHolder(@NonNull Myviewholder holder, int position) {

holder.name.setText(mData.get(position).getName());
        holder.aadhar.setText(mData.get(position).getAadhar());
        holder.address.setText(mData.get(position).getAddress());
        holder.contectno.setText(mData.get(position).getContactNumber());
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "Please Contect Worker", Toast.LENGTH_SHORT).show();
            }
        });

    }



    @Override
    public int getItemCount() {
        return mData.size();

    }

    public class Myviewholder extends RecyclerView.ViewHolder {

        TextView name,aadhar,address,lime2,contectno,licenseno;
        LinearLayout linearLayout;


        public Myviewholder(@NonNull View itemView) {
            super(itemView);
linearLayout=itemView.findViewById(R.id.L_registerb);
            name=itemView.findViewById(R.id.txt);
            aadhar=itemView.findViewById(R.id.aadhora);
            address=itemView.findViewById(R.id.Location);
            lime2=itemView.findViewById(R.id.aaa);
            contectno=itemView.findViewById(R.id.Texture);
            licenseno=itemView.findViewById(R.id.txtaa);
        }
    }
}

