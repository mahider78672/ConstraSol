package com.example.constra_sol.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.constra_sol.Modelclassall.Contructormodelsupplier;
import com.example.constra_sol.R;

import java.util.List;

public class Contractoradaptersupplier extends RecyclerView.Adapter<Contractoradaptersupplier.Myviewholder> {

    private Context mContext;
    private List<Contructormodelsupplier> mData;


    public Contractoradaptersupplier(Context mContext, List<Contructormodelsupplier> mData) {


        this.mContext = mContext;
        this.mData = mData;

    }


    @NonNull
    @Override
    public Myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view;
        LayoutInflater minflater = LayoutInflater.from(mContext);
        view = minflater.inflate(R.layout.supplieruserlayout, parent, false);
        return new Myviewholder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull Myviewholder holder, int position) {

        holder.name.setText(mData.get(position).getName());
        holder.aadhar.setText(mData.get(position).getAadhar());
        holder.address.setText(mData.get(position).getAddress());
        holder.contectno.setText(mData.get(position).getContactNumber());
        holder.lime2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
        /*        String phno="98377765443";

                Intent i=new Intent(Intent.ACTION_DIAL,Uri.parse(phno));
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);

                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
              mContext.  startActivity(i);*/

                Toast.makeText(mContext, "Please Contect Supplier", Toast.LENGTH_SHORT).show();
            }
        });

    }


    @Override
    public int getItemCount() {
        return mData.size();

    }

    public class Myviewholder extends RecyclerView.ViewHolder {

        TextView name, aadhar, address, lime2, contectno, licenseno;
        LinearLayout linearLayout;


        public Myviewholder(@NonNull View itemView) {
            super(itemView);
            lime2=itemView.findViewById(R.id.contectsupplier);

            name=itemView.findViewById(R.id.txtsupplier);
            aadhar=itemView.findViewById(R.id.aadhorsu);
            address=itemView.findViewById(R.id.Location);
            // lime2=itemView.findViewById(R.id.aaa);
            contectno=itemView.findViewById(R.id.Texture);
            //licenseno=itemView.findViewById(R.id.txtaa);
        }
    }
}

