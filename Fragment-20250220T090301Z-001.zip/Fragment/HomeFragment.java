package com.example.constra_sol.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.constra_sol.Login.Contractor_login;
import com.example.constra_sol.R;
import com.example.constra_sol.homedeshboard.CustomContructor;
import com.example.constra_sol.homedeshboard.CustomSupplier;
import com.example.constra_sol.homedeshboard.Datacustomlistview;
import com.example.constra_sol.homedeshboard.Datashowcontructor;


public class HomeFragment extends Fragment {
//TextView contructor,worker,supplier;
CardView  contructor,worker,supplier;


    public HomeFragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View  view= inflater.inflate(R.layout.fragment_home, container, false);
        contructor=view.findViewById(R.id.contrectorcard);
        worker=view.findViewById(R.id.workercard);
        supplier=view.findViewById(R.id.suppliercard);

        contructor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), CustomContructor.class);

                startActivity(intent);
            }
        });

        worker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Datacustomlistview.class);

                startActivity(intent);
            }
        });

        supplier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), CustomSupplier.class);

                startActivity(intent);
            }
        });

        return view;
    }
}