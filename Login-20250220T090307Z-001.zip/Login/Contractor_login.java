package com.example.constra_sol.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.R;
import com.example.constra_sol.homedeshboard.Constrectorhome;
import com.example.constra_sol.utils.Prefs;

public class Contractor_login extends AppCompatActivity {
    Button login;
    RequestQueue queue;
    SharedPreferences sharedPreferences;
    String emailid;
    EditText aadhorno, edpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contractor_login);
        queue = Volley.newRequestQueue(this);
        aadhorno = findViewById(R.id.editText);
        edpassword = findViewById(R.id.editText2);

        sharedPreferences = getSharedPreferences("mysession", MODE_PRIVATE);

        login = findViewById(R.id.btn_Login);
        String aa = sharedPreferences.getString("key", "0");
        if (aa != "0") {
            Intent in = new Intent(Contractor_login.this, Constrectorhome.class);
            startActivity(in);


        }


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkvalidation()) {


                    final String aadhornoo = aadhorno.getText().toString();
                    String password = edpassword.getText().toString();

                   // final String url = "https://www.eglobalexportmart.in/Global.asmx/LoginUser?email=" + email + "&password=" + password;
                    final  String url="https://www.rohitbisht.xyz/Account.asmx/loginmethodcontructor?aadharno="+aadhornoo+"&password="+password;

                    //   final String url = "http://developer.ayyub.buzz/webservice1.asmx/loginmethod?email=" + email + "&password=" + password;
                    //volley library
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Toast.makeText(getApplicationContext(),""+response,Toast.LENGTH_SHORT).show();
                            String aa = response.toString();
                            //   email=url.getstring

                            if (aa.equals("SucessFully Register")) {
                                Prefs.setSharedPreferenceString(Contractor_login.this,"SayLogin","1");

                                /*SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("key", aadhornoo);
                                editor.apply();*/

                                //    SessionManager.getInstance(Login.this).Session(aa);

                                Intent in = new Intent(Contractor_login.this, Constrectorhome.class);
                                //   emailid.putExtra("email", email);
                              //  emailid = sharedPreferences.getString("key", "1");
                                startActivity(in);
                                //  finishAffinity();


                            } else {
                                Toast.makeText(getApplicationContext(), "Login Faild", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();


                        }
                    });
                    queue.add(stringRequest);
                } else {

                }


            }

            private boolean checkvalidation() {

                if (aadhorno.getText().toString().equalsIgnoreCase("")) {
                    aadhorno.setError("Please enter aadhor no");
                    aadhorno.requestFocus();
                    return false;

                } else if (edpassword.getText().toString().equalsIgnoreCase("")) {
                    edpassword.setError("Please Enter Password");
                    edpassword.requestFocus();
                    return false;

                }
                return true;
            }
        });

    }
}
