package com.example.constra_sol.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.R;
import com.example.constra_sol.utils.Prefs;

public class Contractor_signup extends AppCompatActivity {

    RequestQueue requestQueue;
    Button registerbutton;

    EditText name;
    //  View edpassword;
    EditText aadharno;
    EditText worktype;
    EditText address;
    EditText contectno;
    EditText textid;
    EditText licenceno;
    EditText password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contractor_signup);

        registerbutton=findViewById(R.id.conregisterbutton);
        requestQueue= Volley.newRequestQueue(this);
        name=findViewById(R.id.name);
        aadharno=findViewById(R.id.aadhor);

        worktype=findViewById(R.id.workty);
        address=findViewById(R.id.address);
        contectno=findViewById(R.id.contectnoo);
        textid=findViewById(R.id.textidd);
        licenceno=findViewById(R.id.licencenoo);
        password=findViewById(R.id.passwordd);
   /*     registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(Contractor_signup.this, Contractor_login.class);
                startActivity(in);
            }
        });*/



        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkValidation()) {
                    String namee=name.getText().toString();
                    String aadhornoo=aadharno.getText().toString();
                    String worktypee=worktype.getText().toString();


                    String addresss=address.getText().toString();
                    String contectnooo=contectno.getText().toString();
                    String textids=textid.getText().toString();
                    String licensenooo=licenceno.getText().toString();
                    String passwords=password.getText().toString();



                    String Url="https://www.rohitbisht.xyz/Account.asmx/RegisterContractor?name="+namee+"&aadharno="+aadhornoo+"&worktype="+worktypee+"&address="+addresss+"&contactno="+contectnooo+"&textid="+textids+"&licenseno="+licensenooo+"&password="+passwords;


                    //  String url="http://netkoon.com/WebService1.asmx/Registeruploadmethodd?name=" + name + "&email=" + email + "&password=" + password + "&mobile="+ mobile;
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, Url, new  Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Prefs.setSharedPreferenceString(Contractor_signup.this,"name",namee);
                            Prefs.setSharedPreferenceString(Contractor_signup.this,"aadharno",aadhornoo);
                            Prefs.setSharedPreferenceString(Contractor_signup.this,"addresss",addresss);
                            Prefs.setSharedPreferenceString(Contractor_signup.this,"contectnooo",contectnooo);


                    Intent in = new Intent(Contractor_signup.this, Contractor_login.class);
                    startActivity(in);
                            Toast.makeText(getApplicationContext(),"Your Account is Created",Toast.LENGTH_LONG).show();
                            finish();




                            //Toast.makeText(getApplicationContext(),"submit"+response,Toast.LENGTH_SHORT).show();


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();


                        }
                    });
                    requestQueue.add(stringRequest);

                }
                else {

                }

            }

            private boolean checkValidation() {

                if (name.getText().toString().equalsIgnoreCase("")) {
                    name.setError("Please enter your name");
                    name.requestFocus();
                    return false;


                }else if (aadharno.getText().toString().equalsIgnoreCase("")) {
                    aadharno.setError("Please enter your aadhorno");
                    aadharno.requestFocus();
                    return false;








                } else if
                (worktype.getText().toString().equalsIgnoreCase("")) {
                    worktype.setError("Please enter your worktype");
                    worktype.requestFocus();
                    return false;


                } else if (address.getText().toString().equalsIgnoreCase("")) {
                    address.setError("Please enter your address");
                    address.requestFocus();
                    return false;
                } else if (contectno.getText().toString().trim().length() < 10) {
                    contectno.setError("Pin Number Should Be 10 Digits");
                    contectno.requestFocus();
                    return false;

                } else if (textid.getText().toString().equalsIgnoreCase("")) {
                    textid.setError("Please enter your text id");
                    textid.requestFocus();
                    return false;


                } else if (licenceno.getText().toString().equalsIgnoreCase("")) {
                    licenceno.setError("Please enter your Website");
                    licenceno.requestFocus();
                    return false;


                }

                    return  true;
            }



        });



        // VolleyUse






    }


}
