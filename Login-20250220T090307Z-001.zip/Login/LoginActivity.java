package com.example.constra_sol.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.R;
import com.example.constra_sol.homedeshboard.Constrectorhome;
import com.example.constra_sol.homedeshboard.HomeActivity;
import com.example.constra_sol.homedeshboard.Workerhome;
import com.example.constra_sol.utils.Prefs;
import com.example.constra_sol.utils.Prefsuser;

public class LoginActivity extends AppCompatActivity {
    TextView container, userlogin;
    Button loginbuttonuser;
    TextView contractorregister,contractorlogin,workerregisterr,workerlogin,supplierregis,supplierlogin;
    Button loginbuttonmain;

    RequestQueue queue;
    SharedPreferences sharedPreferences;
    String emailid;
    EditText aadhorno, edpassword;

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        finishAffinity();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        sharedPreferences = getSharedPreferences("mysession", MODE_PRIVATE);



        workerregisterr=findViewById(R.id.regworker);
        workerlogin=findViewById(R.id.logworker);
        contractorregister=findViewById(R.id.RegisterConterector);
        contractorlogin=findViewById(R.id.logincontraector);
        supplierregis=findViewById(R.id.regsupplier);
        supplierlogin=findViewById(R.id.loginsupplier);

        loginbuttonuser=findViewById(R.id.button2);
        //container=findViewById(R.id.textView4);
        userlogin=findViewById(R.id.singupnext);


        /*   loginwork*/


        queue = Volley.newRequestQueue(this);
        aadhorno = findViewById(R.id.usermobilee);
        edpassword = findViewById(R.id.userpassword);



        //loginbuttonuser = findViewById(R.id.btn_Loginworker);
   /*     String aa = sharedPreferences.getString("key", "0");
        if (aa != "0") {
            Intent in = new Intent(LoginActivity.this, HomeActivity.class);
            startActivity(in);


        }*/

        String aa = sharedPreferences.getString("key", "0");
        if (aa != "0") {
            Intent in = new Intent(LoginActivity.this, HomeActivity.class);
            startActivity(in);


        }


        loginbuttonuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkvalidation()) {


                    final String mobile= aadhorno.getText().toString();
                    String password = edpassword.getText().toString();

                    // final String url = "https://www.eglobalexportmart.in/Global.asmx/LoginUser?email=" + email + "&password=" + password;
                   // final  String url="https://www.rohitbisht.xyz/Account.asmx/loginmethod?aadharno="+aadhornoo+"&password="+password;

                    final String url ="https://www.rohitbisht.xyz/Account.asmx/loginuser?mobile="+mobile+"&password="+password;

                    //   final String url = "http://developer.ayyub.buzz/webservice1.asmx/loginmethod?email=" + email + "&password=" + password;
                    //volley library
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Toast.makeText(getApplicationContext(),""+response,Toast.LENGTH_SHORT).show();
                            String aa = response.toString();


                            if (aa.equals("SucessFully Register")) {
                                Prefsuser.setSharedPreferenceString(LoginActivity.this,"SayLoginuser","1");



                                //    SessionManager.getInstance(Login.this).Session(aa);

                                Intent in = new Intent(LoginActivity.this, HomeActivity.class);
                                //   emailid.putExtra("email", email);
                                //  emailid = sharedPreferences.getString("key", "1");
                                startActivity(in);
                                //  finishAffinity();


                            } else {
                                Toast.makeText(getApplicationContext(), "Login Faild", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();


                        }
                    });
                    queue.add(stringRequest);
                } else {

                }


            }

            private boolean checkvalidation() {

                if (aadhorno.getText().toString().equalsIgnoreCase("")) {
                    aadhorno.setError("Please enter aadhor no");
                    aadhorno.requestFocus();
                    return false;

                } else if (edpassword.getText().toString().equalsIgnoreCase("")) {
                    edpassword.setError("Please Enter Password");
                    edpassword.requestFocus();
                    return false;

                }
                return true;
            }
        });






workerregisterr.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent logincontain=new Intent(LoginActivity.this, Workersignup.class);
        startActivity(logincontain);
    }
});


        workerlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logincontain=new Intent(LoginActivity.this, Workerlogin.class);
                startActivity(logincontain);
            }
        });

        contractorregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logincontain=new Intent(LoginActivity.this, Contractor_signup.class);
                startActivity(logincontain);
            }
        });


        contractorlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logincontain=new Intent(LoginActivity.this, Contractor_login.class);
                startActivity(logincontain);
            }
        });


        supplierregis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logincontain=new Intent(LoginActivity.this, Suuplier_signup.class);
                startActivity(logincontain);
            }
        });

        supplierlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logincontain=new Intent(LoginActivity.this, Supplier.class);
                startActivity(logincontain);
            }
        });







    /*    loginbuttonuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logincontain=new Intent(LoginActivity.this, HomeActivity.class);
                startActivity(logincontain);
            }
        });*/

        userlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logincontain=new Intent(LoginActivity.this,UserSignup.class);
                startActivity(logincontain);
            }
        });
    }
}