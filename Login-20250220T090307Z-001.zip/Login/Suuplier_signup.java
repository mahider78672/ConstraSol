package com.example.constra_sol.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.R;
import com.example.constra_sol.utils.Prefs;
import com.example.constra_sol.utils.Prefsss;

public class Suuplier_signup extends AppCompatActivity {

    RequestQueue requestQueue;
    Button registerbutton;

    EditText name;
    //  View edpassword;
    EditText aadharno;
    EditText meterialsupplier;
    EditText address;
    EditText contectno;
    EditText textid;
    EditText licenceno;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suuplier_signup);
        registerbutton=findViewById(R.id.supplierregister);
        requestQueue= Volley.newRequestQueue(this);
        name=findViewById(R.id.namesupplier);
        aadharno=findViewById(R.id.aadharcardnosupplier);

        meterialsupplier=findViewById(R.id.meterialsupplier);
        address=findViewById(R.id.addresssupplier);
        contectno=findViewById(R.id.contectsupplier);
        textid=findViewById(R.id.textidsupplier);
        licenceno=findViewById(R.id.licensenosupplier);
        password=findViewById(R.id.passwordsuppplier);
   /*     registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(Contractor_signup.this, Contractor_login.class);
                startActivity(in);
            }
        });*/



        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkValidation()) {
                    String namee=name.getText().toString();
                    String aadhornoo=aadharno.getText().toString();
                    String meterialtype=meterialsupplier.getText().toString();


                    String addresss=address.getText().toString();
                    String contectnooo=contectno.getText().toString();
                    String textids=textid.getText().toString();
                    String licensenooo=licenceno.getText().toString();
                    String passwords=password.getText().toString();



                    String Url="https://www.rohitbisht.xyz/Account.asmx/RegisterSupplier?name="+namee+"&aadharno="+aadhornoo+"&meterialtype="+meterialtype+"&address="+addresss+"&contactno="+contectnooo+"&textid="+textids+"&licenseno="+licensenooo+"&password="+passwords;


                    //  String url="http://netkoon.com/WebService1.asmx/Registeruploadmethodd?name=" + name + "&email=" + email + "&password=" + password + "&mobile="+ mobile;
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, Url, new  Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Prefsss.setSharedPreferenceString(Suuplier_signup.this,"namee",namee);
                            Prefsss.setSharedPreferenceString(Suuplier_signup.this,"aadharnoo",aadhornoo);
                            Prefsss.setSharedPreferenceString(Suuplier_signup.this,"addressss",addresss);
                            Prefsss.setSharedPreferenceString(Suuplier_signup.this,"contectnoooo",contectnooo);


                            Intent in = new Intent(Suuplier_signup.this, Supplier.class);
                            startActivity(in);
                            Toast.makeText(getApplicationContext(),"Your Account is Created",Toast.LENGTH_LONG).show();
                            finish();




                            //Toast.makeText(getApplicationContext(),"submit"+response,Toast.LENGTH_SHORT).show();


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();


                        }
                    });
                    requestQueue.add(stringRequest);

                }
                else {

                }

            }

            private boolean checkValidation() {

                if (name.getText().toString().equalsIgnoreCase("")) {
                    name.setError("Please enter your name");
                    name.requestFocus();
                    return false;


                }else if (aadharno.getText().toString().equalsIgnoreCase("")) {
                    aadharno.setError("Please enter your aadhorno");
                    aadharno.requestFocus();
                    return false;








                } else if
                (meterialsupplier.getText().toString().equalsIgnoreCase("")) {
                    meterialsupplier.setError("Please enter your  meterialtype");
                    meterialsupplier.requestFocus();
                    return false;


                } else if (address.getText().toString().equalsIgnoreCase("")) {
                    address.setError("Please enter your address");
                    address.requestFocus();
                    return false;
                } else if (contectno.getText().toString().trim().length() < 10) {
                    contectno.setError("Pin Number Should Be 10 Digits");
                    contectno.requestFocus();
                    return false;

                } else if (textid.getText().toString().equalsIgnoreCase("")) {
                    textid.setError("Please enter your text id");
                    textid.requestFocus();
                    return false;


                } else if (licenceno.getText().toString().equalsIgnoreCase("")) {
                    licenceno.setError("Please enter your Website");
                    licenceno.requestFocus();
                    return false;


                }

                return  true;
            }



        });



        // VolleyUse






    }


}
