package com.example.constra_sol.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.R;
import com.example.constra_sol.utils.Prefs;

public class UserSignup extends AppCompatActivity {
TextView textView;

EditText name,mobile,password;
    RequestQueue requestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_signup);
        requestQueue= Volley.newRequestQueue(this);
        name=findViewById(R.id.usernamee);
        mobile=findViewById(R.id.usermobile);
        password=findViewById(R.id.userpasswordd);
        textView=findViewById(R.id.userdatabutton);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkValidation()) {
                    String namee=name.getText().toString();
                    String mobilenumber=mobile.getText().toString();

                    String passwords=password.getText().toString();



                  //  String Url="https://www.rohitbisht.xyz/Account.asmx/RegisterContractor?name="+namee+"&aadharno="+aadhornoo+"&worktype="+meterialtype+"&address="+addresss+"&contactno="+contectnooo+"&textid="+textids+"&licenseno="+licensenooo+"&password="+passwords;


                    //  String url="http://netkoon.com/WebService1.asmx/Registeruploadmethodd?name=" + name + "&email=" + email + "&password=" + password + "&mobile="+ mobile;


                    String Url="https://www.rohitbisht.xyz/Account.asmx/Registerusermain?name="+namee+"&mobile="+mobilenumber+"&password="+passwords;
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, Url, new  Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {


                            Intent in = new Intent(UserSignup.this, LoginActivity.class);
                            in.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );
                            in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(in);
                            Toast.makeText(getApplicationContext(),"Your Account is Created",Toast.LENGTH_LONG).show();





                            //Toast.makeText(getApplicationContext(),"submit"+response,Toast.LENGTH_SHORT).show();


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();


                        }
                    });
                    requestQueue.add(stringRequest);

                }
                else {

                }

            }

            private boolean checkValidation() {

                if (name.getText().toString().equalsIgnoreCase("")) {
                    name.setError("Please enter your name");
                    name.requestFocus();
                    return false;


                }else if (mobile.getText().toString().equalsIgnoreCase("")) {
                    mobile.setError("Please enter your Mobileno");
                    mobile.requestFocus();
                    return false;










                }

                return  true;
            }



        });



        // VolleyUse






    }


}

