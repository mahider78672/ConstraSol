package com.example.constra_sol.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.R;
import com.example.constra_sol.homedeshboard.Workerhome;
import com.example.constra_sol.utils.Prefs;
import com.example.constra_sol.utils.Prefss;

public class Workersignup extends AppCompatActivity {



    RequestQueue requestQueue;
    Button registerbutton;

    EditText name;
    //  View edpassword;
    EditText aadharno;
    EditText worktype;
    EditText address;
    EditText contectno;
    EditText bankaccno;
    EditText ifsc;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workersignup);
        registerbutton=findViewById(R.id.registerworker);
        requestQueue= Volley.newRequestQueue(this);
        name=findViewById(R.id.nameworker);
        aadharno=findViewById(R.id.aadhorworker);

        worktype=findViewById(R.id.worktypeworker);
        address=findViewById(R.id.addressworker);
        contectno=findViewById(R.id.contectworker);
        bankaccno=findViewById(R.id.bankacworker);
        ifsc=findViewById(R.id.ifscworker);
        password=findViewById(R.id.passwordworker);
   /*     registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(Contractor_signup.this, Contractor_login.class);
                startActivity(in);
            }
        });*/



        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkValidation()) {
                    String namee=name.getText().toString();
                    String aadhornoo=aadharno.getText().toString();
                    String meterialtype=worktype.getText().toString();


                    String addresss=address.getText().toString();
                    String contectnooo=contectno.getText().toString();
                    String bankaccount=bankaccno.getText().toString();
                    String ifscc=ifsc.getText().toString();
                    String passwords=password.getText().toString();



                    String Url="https://www.rohitbisht.xyz/Account.asmx/RegisterWorker?name="+namee+"&aadharno="+aadhornoo+"&workingtype="+meterialtype+"&address="+addresss+"&contactno="+contectnooo+"&bankaccno="+bankaccount+"&ifsccode="+ifscc+"&password="+passwords;






                    //  String url="http://netkoon.com/WebService1.asmx/Registeruploadmethodd?name=" + name + "&email=" + email + "&password=" + password + "&mobile="+ mobile;
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, Url, new  Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Prefss.setSharedPreferenceString(Workersignup.this,"name",namee);
                            Prefss.setSharedPreferenceString(Workersignup.this,"aadharno",aadhornoo);
                            Prefss.setSharedPreferenceString(Workersignup.this,"addresss",addresss);
                            Prefss.setSharedPreferenceString(Workersignup.this,"contactno",contectnooo);


                            Intent in = new Intent(Workersignup.this, Workerlogin.class);
                            startActivity(in);
                            Toast.makeText(getApplicationContext(),"Your Account is Created",Toast.LENGTH_LONG).show();
                            finish();




                            //Toast.makeText(getApplicationContext(),"submit"+response,Toast.LENGTH_SHORT).show();


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_SHORT).show();


                        }
                    });
                    requestQueue.add(stringRequest);

                }
                else {

                }

            }

            private boolean checkValidation() {

                if (name.getText().toString().equalsIgnoreCase("")) {
                    name.setError("Please enter your name");
                    name.requestFocus();
                    return false;


                }else if (aadharno.getText().toString().equalsIgnoreCase("")) {
                    aadharno.setError("Please enter your aadhorno");
                    aadharno.requestFocus();
                    return false;








                } else if
                (worktype.getText().toString().equalsIgnoreCase("")) {
                    worktype.setError("Please enter your  worktype");
                    worktype.requestFocus();
                    return false;


                } else if (address.getText().toString().equalsIgnoreCase("")) {
                    address.setError("Please enter your address");
                    address.requestFocus();
                    return false;
                } else if (contectno.getText().toString().trim().length() < 10) {
                    contectno.setError("Pin Number Should Be 10 Digits");
                    contectno.requestFocus();
                    return false;

                } else if (bankaccno.getText().toString().equalsIgnoreCase("")) {
                    bankaccno.setError("Please enter your bankacc");
                    bankaccno.requestFocus();
                    return false;


                } else if (ifsc.getText().toString().equalsIgnoreCase("")) {
                    ifsc.setError("Please enter your ifsccode");
                    ifsc.requestFocus();
                    return false;


                }

                return  true;
            }



        });



        // VolleyUse






    }


}
