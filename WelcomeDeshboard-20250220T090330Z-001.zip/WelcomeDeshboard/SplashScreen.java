package com.example.constra_sol.WelcomeDeshboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.example.constra_sol.Login.LoginActivity;
import com.example.constra_sol.Login.Workersignup;
import com.example.constra_sol.R;
import com.example.constra_sol.homedeshboard.Constrectorhome;
import com.example.constra_sol.homedeshboard.HomeActivity;
import com.example.constra_sol.homedeshboard.Supplierhome;
import com.example.constra_sol.homedeshboard.Workerhome;
import com.example.constra_sol.utils.Prefs;
import com.example.constra_sol.utils.Prefss;
import com.example.constra_sol.utils.Prefsss;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (Prefs.getSharedPreferenceString(SplashScreen.this,"SayLogin","").equals("1")) {
                    Intent welcomeactivity = new Intent(SplashScreen.this, Constrectorhome.class);
                    startActivity(welcomeactivity);



                }else if (Prefss.getSharedPreferenceString(SplashScreen.this,"SayLoginn","").equals("1")) {
                    Intent welcomeactivity = new Intent(SplashScreen.this, Workerhome.class);
                    startActivity(welcomeactivity);









                } else if
                (Prefsss.getSharedPreferenceString(SplashScreen.this,"SayLoginnn","").equals("1")) {
                    Intent welcomeactivity = new Intent(SplashScreen.this, Supplierhome.class);
                    startActivity(welcomeactivity);

                } else if
                (Prefsss.getSharedPreferenceString(SplashScreen.this,"SayLoginuser","").equals("1")) {
                    Intent welcomeactivity = new Intent(SplashScreen.this, HomeActivity.class);
                    startActivity(welcomeactivity);

                }else {
                    Intent intengt = new Intent(SplashScreen.this, LoginActivity.class);
                    startActivity(intengt);
                }




  /*              if (Prefs.getSharedPreferenceString(SplashScreen.this,"SayLogin","").equals("1")) {
                    Intent welcomeactivity = new Intent(SplashScreen.this, Constrectorhome.class);
                    startActivity(welcomeactivity);
                } else {
                    Intent intent = new Intent(SplashScreen.this, LoginActivity.class);
                    startActivity(intent);

                    if (Prefss.getSharedPreferenceString(SplashScreen.this, "SayLoginn", "").equals("2")) {
                        Intent welcomeactivityy = new Intent(SplashScreen.this, Workerhome.class);
                        startActivity(welcomeactivityy);
                    } else {
                        Intent intentr = new Intent(SplashScreen.this, LoginActivity.class);
                        startActivity(intentr);


                        if (Prefsss.getSharedPreferenceString(SplashScreen.this, "SayLoginnn", "").equals("3")) {
                            Intent welcomeactivityyw = new Intent(SplashScreen.this, Supplierhome.class);
                            startActivity(welcomeactivityyw);
                        } else {
                            Intent intengt = new Intent(SplashScreen.this, LoginActivity.class);
                            startActivity(intengt);


                        }
                    }*/


            }
        }, 3000);
    }
}