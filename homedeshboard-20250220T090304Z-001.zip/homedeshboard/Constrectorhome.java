package com.example.constra_sol.homedeshboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.Adapter.Contractoradapter;
import com.example.constra_sol.Login.Contractor_login;
import com.example.constra_sol.Login.LoginActivity;
import com.example.constra_sol.Modelclassall.Contructormodel;
import com.example.constra_sol.R;
import com.example.constra_sol.utils.Prefs;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Constrectorhome extends AppCompatActivity {
    public RequestQueue requestQueue;
    //    Contructormodel contructormodel;
    TextView insertdetail;

    /*    ArrayList<Contructormodel> arrayList;
        Contractoradapter contractoradapter;
        private RecyclerView.LayoutManager mLayoutManager;
        RecyclerView constructorrecyclerview;*/
    SharedPreferences sharedPreferences;
    String emailid;
    private TextView tvName, tvAdhdhar, tvMob, tvAdd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_constrectorhome);




        sharedPreferences = getSharedPreferences("mysession", MODE_PRIVATE);


        insertdetail = findViewById(R.id.insertdetail);

        insertdetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Prefs.logout(Constrectorhome.this, "SayLogin");
                Intent intent = new Intent(Constrectorhome.this, LoginActivity.class);
                startActivity(intent);

            }
        });

        /**
         write code by sikandar
         */
        tvName = findViewById(R.id.tv_name);
        tvAdhdhar = findViewById(R.id.tv_adhdhar);
        tvMob = findViewById(R.id.tv_mob);
        tvAdd = findViewById(R.id.tv_add);
        tvName.setText("Name: " + Prefs.getSharedPreferenceString(Constrectorhome.this, "name", ""));
        tvAdhdhar.setText("Aadhar No: " + Prefs.getSharedPreferenceString(Constrectorhome.this, "aadharno", ""));
        tvMob.setText("Mobile No: " + Prefs.getSharedPreferenceString(Constrectorhome.this, "contectnooo", ""));
        tvAdd.setText("Address: " + Prefs.getSharedPreferenceString(Constrectorhome.this, "addresss", ""));

        /* insert click*/


        //  constructorrecyclerview=findViewById(R.id.recyclercon);
      /*  arrayList = new ArrayList<>();
        requestQueue = Volley.newRequestQueue(this);





        setProdItemRecycler(arrayList);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://www.rohitbisht.xyz/Account.asmx/contructorHistory", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        contructormodel = new Contructormodel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        int id = jsonObject1.getInt("id");
                        String name = jsonObject1.getString("name");
                        String aadharnoo = jsonObject1.getString("aadharno");
                        String address = jsonObject1.getString("address");
                        String contectno = jsonObject1.getString("contactno");
                       *//* String textid = jsonObject1.getString("taxid");
                        String licenseno = jsonObject1.getString("licenceno");*//*

                        contructormodel.setName(name) ;
                        contructormodel.setAadhar(aadharnoo);
                        contructormodel.setAddress(address);
                        contructormodel.setAadhar(contectno);
                       *//* contructormodel.setAddress(textid);
                        contructormodel.setAadhar(licenseno);*//*

                        contructormodel.setId(id);
                        arrayList.add(contructormodel);
                    }
                    Contractoradapter customListAdapter = new Contractoradapter(getApplicationContext(), arrayList);
                    constructorrecyclerview  .setAdapter(customListAdapter);


                } catch (JSONException e) {


                    e.printStackTrace();
                }
                //  Toast.makeText(getApplicationContext(), "" + response, Toast.LENGTH_LONG).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(stringRequest);









    }

    private void setProdItemRecycler(ArrayList<Contructormodel> arrayList) {

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false);
        constructorrecyclerview.setLayoutManager(layoutManager);
        constructorrecyclerview.setHasFixedSize(true);
    }*/


    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        super.onBackPressed();
    }
}