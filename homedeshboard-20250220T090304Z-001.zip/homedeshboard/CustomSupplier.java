package com.example.constra_sol.homedeshboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.constra_sol.Adapter.MyListAdapterr;
import com.example.constra_sol.Adapter.MyListAdapterrr;
import com.example.constra_sol.R;

public class CustomSupplier extends AppCompatActivity {

    ListView list;

    String[] maintitle ={
            "Construction Material","Electrical Materials",
            "Painting Materials","Carpentery Materials",
            "plumber's material",
    };

    String[] subtitle ={
            "Sub Title 1","Sub Title 2",
            "Sub Title 3","Sub Title 4",
            "Sub Title 5",
    };

    Integer[] imgid={
            R.drawable.spllll,R.drawable.spllll,
            R.drawable.spllll,R.drawable.spllll,
            R.drawable.spllll,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_supplier);
        MyListAdapterrr adapter=new MyListAdapterrr(this, maintitle, subtitle,imgid);
        list=(ListView)findViewById(R.id.listsupplier);
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent=new Intent(CustomSupplier.this,UserSupplierhome.class);
                startActivity(intent);
                // TODO Auto-generated method stub
/*                if(position == 0) {
                    //code specific to first list item
                }

                else if(position == 1) {
                    //code specific to 2nd list item
                    Toast.makeText(getApplicationContext(),"Place Your Second Option Code",Toast.LENGTH_SHORT).show();
                }

                else if(position == 2) {

                    Toast.makeText(getApplicationContext(),"Place Your Third Option Code",Toast.LENGTH_SHORT).show();
                }
                else if(position == 3) {

                    Toast.makeText(getApplicationContext(),"Place Your Forth Option Code",Toast.LENGTH_SHORT).show();
                }
                else if(position == 4) {

                    Toast.makeText(getApplicationContext(),"Place Your Fifth Option Code",Toast.LENGTH_SHORT).show();
                }*/

            }
        });
    }
}