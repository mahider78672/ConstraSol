package com.example.constra_sol.homedeshboard;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.example.constra_sol.Fragment.HomeFragment;
import com.example.constra_sol.Fragment.Profilefragment;
import com.example.constra_sol.Login.LoginActivity;
import com.example.constra_sol.MainActivity;
import com.example.constra_sol.Navigation.First;
import com.example.constra_sol.R;
import com.example.constra_sol.utils.Prefss;
import com.example.constra_sol.utils.Prefsuser;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener, NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout dd_drawer;
    ImageView drawer_img;
    SharedPreferences sharedPreferences;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        sharedPreferences = getSharedPreferences("mysession", MODE_PRIVATE);
        drawer_img=findViewById(R.id.img_drawer);
     //   drawer_img.setBackgroundResource(ic_menu);
        //bottom navigatio
        BottomNavigationView bottomNav = findViewById(R.id.botttom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(this);
        getFragments(new HomeFragment());
//drawer navigation........
        dd_drawer=findViewById(R.id.dd_drawer);
        NavigationView navigationView=findViewById(R.id.navigation);
        drawer_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dd_drawer.openDrawer(GravityCompat.START);
             //   drawer_img.setBackgroundResource(ic_left_arrow);
                if (dd_drawer.isDrawerOpen(GravityCompat.START)){
                    dd_drawer.closeDrawer(GravityCompat.START);
                   // drawer_img.setBackgroundResource();
                }
            }
        });
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem itemView) {
                switch (itemView.getItemId()) {
                    case R.id.home:
                        startActivity(new Intent(HomeActivity.this, HomeActivity.class));
                        break;
                    case R.id.contructors:
                        startActivity(new Intent(HomeActivity.this, CustomContructor.class));
                        break;
                    case R.id.workers:
                        startActivity(new Intent(HomeActivity.this, CustomContructor.class));
                        break;
                    case R.id.about:
                        startActivity(new Intent(HomeActivity.this, First.class));
                        break;

                    case R.id.logout:
                        Prefsuser.logout(HomeActivity.this, "SayLoginuser");
                        Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                        startActivity(intent);;
                        break;
                    case R.id.share:

                        Intent in = new Intent(Intent.ACTION_SEND);
                        in.setType("text/plain");
                        in.putExtra(Intent.EXTRA_TEXT, "hello");
                        startActivity(in);
                        break;



                }
                return true;
            }
        });



    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.home:
                getFragments(new HomeFragment());
                break;
            case R.id.course:
                getFragments(new Profilefragment());
                break;
            case R.id.profile:
                getFragments(new Profilefragment());
                break;
        }
        return true;
    }
    public void getFragments(Fragment fragment){
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        super.onBackPressed();
    }
}