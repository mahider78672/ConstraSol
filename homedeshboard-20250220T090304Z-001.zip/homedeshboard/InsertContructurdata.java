package com.example.constra_sol.homedeshboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.constra_sol.R;

public class InsertContructurdata extends AppCompatActivity {
    TextView  insertdata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_contructurdata);
        insertdata=findViewById(R.id.insertdatabutton);
        /*insertdata=findViewById(R.id.insertdatabutton);*/

        insertdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(InsertContructurdata.this, "your data is insert Thankyou", Toast.LENGTH_SHORT).show();
            }
        });
    }
}