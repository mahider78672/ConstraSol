package com.example.constra_sol.homedeshboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.example.constra_sol.Adapter.Contractoradapter;
import com.example.constra_sol.Login.Contractor_login;
import com.example.constra_sol.Login.LoginActivity;
import com.example.constra_sol.Modelclassall.Contructormodel;
import com.example.constra_sol.R;
import com.example.constra_sol.utils.Prefs;
import com.example.constra_sol.utils.Prefss;
import com.example.constra_sol.utils.Prefsss;

import java.util.ArrayList;

public class Supplierhome extends AppCompatActivity {
    public RequestQueue requestQueue;
    Contructormodel contructormodel;
    TextView insertdetail;

    ArrayList<Contructormodel> arrayList;
    Contractoradapter contractoradapter;
    private RecyclerView.LayoutManager mLayoutManager;
    RecyclerView constructorrecyclerview;
    SharedPreferences sharedPreferences;
    String emailid;
    private TextView tvName,tvAdhdhar,tvMob,tvAdd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplierhome);

        sharedPreferences=getSharedPreferences("mysession",MODE_PRIVATE);


        insertdetail=findViewById(R.id.insertdetail);

        insertdetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Prefsss.logout(Supplierhome.this,"SayLoginnn");
                Intent intent=new Intent(Supplierhome.this, LoginActivity.class);
                startActivity(intent);

            }
        });

        /**
         write code by sikandar
         */
        tvName=findViewById(R.id.tv_name);
        tvAdhdhar=findViewById(R.id.tv_adhdhar);
        tvMob=findViewById(R.id.tv_mob);
        tvAdd=findViewById(R.id.tv_add);
        tvName.setText("Name: "+ Prefsss.getSharedPreferenceString(Supplierhome.this,"namee",""));
        tvAdhdhar.setText("Aadhar No: "+ Prefsss.getSharedPreferenceString(Supplierhome.this,"aadharnoo",""));
        tvMob.setText("Mobile No: "+Prefsss.getSharedPreferenceString(Supplierhome.this,"contectnoooo",""));
        tvAdd.setText("Address: "+Prefsss.getSharedPreferenceString(Supplierhome.this,"addressss",""));

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}