package com.example.constra_sol.homedeshboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.Adapter.Contractoradapter;
import com.example.constra_sol.Adapter.Contractoradapterworker;
import com.example.constra_sol.Modelclassall.Contructormodel;
import com.example.constra_sol.Modelclassall.Contructormodelsupplier;
import com.example.constra_sol.Modelclassall.modelworker;
import com.example.constra_sol.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class UserContructor extends AppCompatActivity {
    public RequestQueue requestQueue;
    com.example.constra_sol.Modelclassall.modelworker modelworkerr;
    TextView insertdetail;

    ArrayList<modelworker> arrayList;
    com.example.constra_sol.Adapter.Contractoradapterworker Contractoradapterworker;
    private RecyclerView.LayoutManager mLayoutManager;
    RecyclerView contruecyclerview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_contructor);
        contruecyclerview=findViewById(R.id.recyclerusercon);
        arrayList = new ArrayList<>();
        requestQueue = Volley.newRequestQueue(this);


        setProdItemRecycler(arrayList);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://www.rohitbisht.xyz/Account.asmx/contructorHistory", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        modelworkerr = new modelworker();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        int id = jsonObject1.getInt("id");
                        String name = jsonObject1.getString("name");
                        String aadharnoo = jsonObject1.getString("aadharno");
                        String address = jsonObject1.getString("address");
                        String contectno = jsonObject1.getString("contactno");
                       /* String textid = jsonObject1.getString("taxid");
                        String licenseno = jsonObject1.getString("licenceno");*/

                        modelworkerr.setName(name);
                        modelworkerr.setAadhar(aadharnoo);
                        modelworkerr.setAddress(address);
                        modelworkerr.setContactNumber(contectno);
                       /* contructormodel.setAddress(textid);
                        contructormodel.setAadhar(licenseno);*/

                        modelworkerr.setId(id);
                        arrayList.add(modelworkerr);
                    }
                    com.example.constra_sol.Adapter.Contractoradapterworker customListAdapter = new Contractoradapterworker(getApplicationContext(), arrayList);
                    contruecyclerview.setAdapter(customListAdapter);


                } catch (JSONException e) {


                    e.printStackTrace();
                }
                //  Toast.makeText(getApplicationContext(), "" + response, Toast.LENGTH_LONG).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(stringRequest);


    }

    private void setProdItemRecycler(ArrayList<modelworker> arrayList) {

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false);
        contruecyclerview.setLayoutManager(layoutManager);
        contruecyclerview.setHasFixedSize(true);
    }
}

