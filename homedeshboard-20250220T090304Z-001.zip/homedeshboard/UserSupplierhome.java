package com.example.constra_sol.homedeshboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.Adapter.Contractoradapter;
import com.example.constra_sol.Adapter.Contractoradaptersupplier;
import com.example.constra_sol.Modelclassall.Contructormodel;
import com.example.constra_sol.Modelclassall.Contructormodelsupplier;
import com.example.constra_sol.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class UserSupplierhome extends AppCompatActivity {
    public RequestQueue requestQueue;
    Contructormodelsupplier Contructormodelsupplier;
    TextView insertdetail;

    ArrayList<Contructormodelsupplier> arrayList;
    com.example.constra_sol.Adapter.Contractoradaptersupplier Contractoradaptersupplier;
    private RecyclerView.LayoutManager mLayoutManager;
    RecyclerView suppplierrecyclerview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_supplierhome);
        arrayList = new ArrayList<>();
        requestQueue = Volley.newRequestQueue(this);
        suppplierrecyclerview=findViewById(R.id.recyclersupplier);

        setProdItemRecycler(arrayList);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, "https://www.rohitbisht.xyz/Account.asmx/supplierHistory", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        Contructormodelsupplier = new Contructormodelsupplier();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        int id = jsonObject1.getInt("id");
                        String name = jsonObject1.getString("name");
                        String aadharnoo = jsonObject1.getString("aadharno");
                        String address = jsonObject1.getString("address");
                        String contectno = jsonObject1.getString("contactno");
                       /* String textid = jsonObject1.getString("taxid");
                        String licenseno = jsonObject1.getString("licenceno");*/

                        Contructormodelsupplier.setName(name);
                        Contructormodelsupplier.setAadhar(aadharnoo);
                        Contructormodelsupplier.setAddress(address);
                        Contructormodelsupplier.setContactNumber(contectno);
                       /* contructormodel.setAddress(textid);
                        contructormodel.setAadhar(licenseno);*/

                        Contructormodelsupplier.setId(id);
                        arrayList.add(Contructormodelsupplier);
                    }
                    Contractoradaptersupplier customListAdapter = new Contractoradaptersupplier(getApplicationContext(), arrayList);
                    suppplierrecyclerview.setAdapter(customListAdapter);


                } catch (JSONException e) {


                    e.printStackTrace();
                }
                //  Toast.makeText(getApplicationContext(), "" + response, Toast.LENGTH_LONG).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "" + error, Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(stringRequest);


    }

    private void setProdItemRecycler(ArrayList<com.example.constra_sol.Modelclassall.Contructormodelsupplier> arrayList) {

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false);
        suppplierrecyclerview.setLayoutManager(layoutManager);
        suppplierrecyclerview.setHasFixedSize(true);
    }
}

