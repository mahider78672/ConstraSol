package com.example.constra_sol.homedeshboard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.constra_sol.Adapter.Contractoradapter;
import com.example.constra_sol.Login.LoginActivity;
import com.example.constra_sol.Modelclassall.Contructormodel;
import com.example.constra_sol.R;
import com.example.constra_sol.utils.Prefs;
import com.example.constra_sol.utils.Prefss;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Workerhome extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    String emailid;
    private TextView tvName, tvAdhdhar, tvMob, tvAdd;
    TextView insertdetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workerhome);


        sharedPreferences = getSharedPreferences("mysession", MODE_PRIVATE);


        insertdetail = findViewById(R.id.insertdetailw);

        insertdetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Prefss.logout(Workerhome.this, "SayLoginn");
                Intent intent = new Intent(Workerhome.this, LoginActivity.class);
                startActivity(intent);

            }
        });

        /**
         write code by Nishat Anjum ,Haider Abidi, Sadiyakhatoon
         */
        tvName = findViewById(R.id.tv_namew);
        tvAdhdhar = findViewById(R.id.tv_adhdharw);
        tvMob = findViewById(R.id.tv_mobw);
        tvAdd = findViewById(R.id.tv_addw);
        tvName.setText("Name: " + Prefss.getSharedPreferenceString(Workerhome.this, "name", ""));
        tvAdhdhar.setText("Aadhar No: " + Prefss.getSharedPreferenceString(Workerhome.this, "aadharno", ""));
        tvMob.setText("Mobile No: " + Prefss.getSharedPreferenceString(Workerhome.this, "contactno", ""));
        tvAdd.setText("Address: " + Prefss.getSharedPreferenceString(Workerhome.this, "addresss", ""));

    }

    @Override
    public void onBackPressed() {
        finishAffinity();
        super.onBackPressed();
    }
}
